package com.ltx;

public class Constants {

	public static final String YES = "yes";
	public static final String NO = "no";
}
