package com.ltx;

import java.util.*;


public class CityConnections {
	private Map<String, Set<String>> neighbourMap = new HashMap<>();

	/**
	 * adds source and destination pair and destination and source pair
	 * @param source
	 * @param destination
	 */
	public void addEdge(String source, String destination) {
		
		Set<String> neighbours = neighbourMap.get(source);
		if (Objects.isNull(neighbours)) {
			neighbours = new HashSet<String>();
			neighbourMap.put(source, neighbours);
		}
		neighbours.add(destination);
		
		//add reverse mapping
		neighbours = neighbourMap.get(destination);
		if (Objects.isNull(neighbours)) {
			neighbours = new HashSet<String>();
			neighbourMap.put(destination, neighbours);
		}
		neighbours.add(source);
		
	}

	/**
	 * checks whether a path exist between source and destination
	 * @param source
	 * @param destination
	 * @return true - if path exist, false otherwise
	 */
	public boolean pathExist(String source, String destination) {
		
		if (!neighbourMap.containsKey(source) || !neighbourMap.containsKey(destination)) {
			return false;
		}
		
				
		Queue<String> citiesSoFar = new LinkedList<>();
		citiesSoFar.addAll( neighbourMap.get(source));
		
		Set<String> visited = new HashSet<String>(neighbourMap.keySet().size());
		
		visited.add(source);
		boolean found = false;
		while (!citiesSoFar.isEmpty()) {
			
			String city = citiesSoFar.poll();
			
			if (city.equalsIgnoreCase(destination)) {
				found = true;
				break;
			} else {
				if (!visited.contains(city)) {
				Set<String> cityNeighbours = neighbourMap.get(city);
				visited.add(city);
				// add connected links for this city excluding the ones which have been visited already
				for (String neighbour : cityNeighbours) {
					if (!visited.contains(neighbour)) {
						citiesSoFar.add(neighbour);
					}
				}
				}
			}
		}
		return found;
	}
}
