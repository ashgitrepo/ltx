package com.ltx;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.*;

import com.google.common.base.Preconditions;

/**
 * CSV FileReader that reads edges from the file.
 * at present this reads the file from current directory where the program is run
 * @author agarg
 *
 */
public class CityConnectionReader {
	
	public final String FILENAME;


	public CityConnectionReader(String filename) {
		Preconditions.checkArgument(Objects.nonNull(filename), "filename cannot be empty");
		FILENAME = filename;
	}
	
	/**
	 * 
	 * @return a list of connections if the file is valid, empty list otherwise
	 */
	 public Optional<List<String[]>> readEdges(){

	  List<String[]> connections = new ArrayList<>();
	  try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {

	   String line;

	   while ((line = br.readLine()) != null) {
		  boolean valid = validateFile(line);
		  if (!valid) {
			  return Optional.empty();
		  }
		  String[] connection = line.split(",");
		  connections.add(new String[]{connection[0].trim(), connection[1].trim()});
	   }
	   return Optional.of(connections);
	  } catch (IOException e) {
		//  e.printStackTrace(); //can be used for logging
		  return Optional.empty();
	  }
	 }

	 /**
	  * if any of the line contains more than one , or no , we reject the entire file
	  * @param line
	  * @return
	  */
private boolean validateFile(String line) {
	// TODO Auto-generated method stub
	if (!line.contains(",") || line.split(",").length!=2) {
		return false;
	}
	return true;
	}
}
